-- 1.2.1-master


-- version
UPDATE `playsms_tblRegistry` SET `registry_value` = '1.2.1' WHERE `registry_group` = 'core' AND `registry_family` = 'config' AND `registry_key` = 'playsms_version' ;
