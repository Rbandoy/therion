ALTER TABLE `playsms_tblSMSOutgoing` CHANGE `p_footer` `p_footer` VARCHAR( 30 ) NOT NULL DEFAULT '';

