$(document).ready(function() {
	$('.button').addClass('btn');
	$('.button').addClass('btn-primary');
	$('.playsms-table-list').addClass('table');
	$('.playsms-table-list').addClass('table-striped');
	$('.playsms-table-list').addClass('table-hover');
	$('.playsms-table-list').addClass('table-condensed');
	$('.playsms-table-list').tablesorter();
	$('.playsms-table').addClass('table');
	$('.playsms-table').addClass('table-hover');
	$('.playsms-table').addClass('table-condensed');
	$('.playsms-tooltip').tooltip();
	$('.playsms-mandatory').tooltip();
});
