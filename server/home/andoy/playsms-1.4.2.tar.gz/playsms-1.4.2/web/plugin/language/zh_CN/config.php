<?php
$plugin_config['zh_CN']['title'] = 'Chinese (China)';
