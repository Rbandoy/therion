<?php
$plugin_config['da_DK']['title'] = 'Dansk (Danmark)';
