Visit [http://help.playsms.org/](http://help.playsms.org/) and [https://github.com/playsms/book-playsms](https://github.com/playsms/book-playsms)
